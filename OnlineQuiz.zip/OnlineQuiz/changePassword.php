<?php
	require_once('connection.php');
	if(!isset($_SESSION['email'])){
        header("location:login.php");
    }
    else{
        $login=TRUE;
    }

?>

<!DOCTYPE html>
<html>
<head>
	<title>TestYourThreshold | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

	<script>
		function changePass(){
			var flag = true;
			if(document.getElementById('oldPass').value ==''){
				document.getElementById('oldPassError').innerHTML = "Enter Old Password"
                flag =  false;
			}
			if(document.getElementById('newPass').value ==''){
				document.getElementById('newPassError').innerHTML = "Enter New Password"
               flag =  false;
			}
			if(document.getElementById('conPass').value ==''){
				document.getElementById('conPassError').innerHTML = "Enter Password Again"
               flag =  false;
			}
			if(document.getElementById('conPass').value != document.getElementById('newPass').value ){
                alert("Passwords Not Matched");
               flag =  false; 
            }
			var pass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
			if(! (document.getElementById('newPass').value).match(pass)){
			 alert("Password must have 6 character,one Uppercase,One Smallcase and a digit.");
                flag =  false;
			}
			 
			return flag;
		}

        function showOldPass() {
          var x = document.getElementById("oldPass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }

        function shownewPass() {
          var x = document.getElementById("newPass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }

        function showconPass() {
          var x = document.getElementById("conPass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }

	</script>
</head>
<body>
<div class="wrapper">
   	<div id="header">
  <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
  </nav> 
  <nav class="navNew">
    <form class="search" action="search.php"> 
      <input name="q" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="quizLandingPage.php" class="aNew">Home</a>
        </li>
          <li class="liNew">
        <a href="logout.php" class="aNew">LogOut</a>
        </li>
          </li>
        </ul>        
      </li>
    </ul>
  </nav>
</div><!--End of header-->
    <div style="background-image: linear-gradient(#000,#2d2d2d,#262626,#000)" class="mainBody">
        <div class="wrap">
            <center>
                <div class="changePasswordBox">
                    <h3><i style="margin-bottom: 15px" class="fa fa-lock fa-4x"></i></h3></br>
                    <h2 style="margin-bottom: 15px; font-size: 30px" >Change Password?</h2>
                    <p style="margin-bottom: 15px; font-size:14px">You can change your password here.</p></br>
                    <form method="post" action="changePassword.php?action=change" id="changePasswordForm" onsubmit="return changePass()">
                        <input type=password placeholder=" Enter Old Password" name="oldPass" id="oldPass" style="width:300px" required> 
                        <p id="oldPassError" class="redFont"></p>
                        <span  class="fa fa-eye eye-icon" onclick="showOldPass()"></span>
                        <input type=password placeholder=" Enter New Password" id="newPass" name="newPass" style="width:300px" required>
                        <p id="newPassError" class="redFont"></p>
                         <span  class="fa fa-eye eye-icon" onclick="shownewPass()"></span>
                        <input type=password placeholder=" Confirm Password" id="conPass" name="confirmPass" style="width:300px;" required>
                        <p id="conPassError" class="redFont"></p>
                        <span  class="fa fa-eye eye-icon" onclick="showconPass()"></span>
                        <input class="changePasswordButton " value="Change Password" type="submit">  
                    </form>
                </div>
            </center>    
	
		</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
	
</div><!--End of wrapper-->
</body>
</html>
<?php
if(isset($_GET['action'])){
		$email = $_SESSION['email'];
        $sql = "SELECT user_pass FROM mst_user WHERE user_email='$email'";
        $result = mysqli_query($con,$sql);
        $row = mysqli_fetch_assoc($result);
        $oldPass = md5($_POST['oldPass']);
        if($row['user_pass'] == $oldPass){
            $newPass = md5($_POST['newPass']);
            mysqli_query($con,"UPDATE mst_user SET user_pass = '".$newPass."'");
            echo "<script> alert('Password Changed Successfully')</script>";
        }
        else{
            echo "<script> alert('Wrong Old Password')</script>";
        }
    }

?>

