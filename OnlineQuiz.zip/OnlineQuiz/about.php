<?php
    require_once('connection.php');
    if (isset($_SESSION['email'])){
        $login=TRUE;
    }
    else{
        $login=FALSE;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="wrapper">
    <div class="shell-header">
        <div class="wrap">
            <nav>
                <a href="index.php"><div class="logo" style="margin-top:0;margin-left:0"></div></a>
             </nav>
            <!--div class="logo">
				OnlineQuiz
            </div-->
            <div class="menu">
                 <nav>
                    <ul class="disableSelect">
                        <li><a href="index.php" class="<?php echo ($login?'hide':'show');?>">HOME</a></li>
                        <li><a href="quizLandingPage.php" class="<?php echo ($login?'show':'hide');?>">HOME</a></li>
                        <!--li><a href="contact.php">CONTACT US</a></li-->
                        <!--li><a href="login.php"class="<?php echo ($login?'show':'hide');?>">LOGIN</a></li-->
                        <!--li><a href="admin\index.php" class="<?php echo ($login?'hide':'show');?>">ADMIN</a></li-->
                        <li><a href="logout.php" class="<?php echo ($login?'show':'hide');?>">LOGOUT</a></li>

                    </ul>
                </nav>
            </div>
        <div class="clearFix"></div>
        </div>
    </div><!--End of header-->
    <div style="background-image: linear-gradient(#fff,#fff,#000)" class="shell" style="height:100">
		<div class="shell-body">
		<center>
		<div class="head">
				<h1 class="disableSelect yellowFont" style="font-size:150%"> About Us</h1>
		</div>
        <div class="aboutBody">
            <p>TestYourThreshold is an online based custom quiz application. It provides an user interactive environment and let the user practice quizzes on different topics available in the application.Users have to register themselves to our portal in order to avail quiz services.It contains all the results of the users and users can check their results after logging. Feel free to use and register now to avail the quiz services.
No subscription fee is required, users can enjoy unlimited access to OnlineQuiz, provided they register themselves.</p>
            <p>TestYourThreshold plans to provide the users a platform which will be useful to them in everty fields of their life. All the quizzes are MCQ based and comes with four options, only one is the correct answer. They can participate in the quizzes and can nurture themselves for the competitive examinations which are online based, and also examinations for job purposes. They will become accustomed to the e-learning platform. Many companies and developing websites solely for the purpose of online education and we are no different.</p>
        </div>

        </center>

        </div>
    </div>
       <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
    
</div>
</body>
</html>
        
