<?php
//error_reporting(E_WARNING);
error_reporting(E_ERROR | E_PARSE);
error_reporting(0);
include 'connection.php';
    $msg ='';
$mailSuccess ='';
	$foundResult ='';
	if(!isset($_SESSION['email'])){
        //header("location:index.php");
    }
    else{
        $login=TRUE;
    }
	if(isset($_GET['status'])){
		if(base64_decode(urldecode($_GET['status']))=='success'){
			$mailSuccess = '1';

		}
		elseif(base64_decode(urldecode($_GET['status']))=='error'){
			$mailSuccess='0';
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        function validateEmail(email){
            var re=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function checkNull(id){

            if (document.getElementById(id).value==''){
                document.getElementById(id).classList.add('redBorder');
                return false;
            }
            else{
                document.getElementById(id).classList.remove('redBorder');
                return true;
            }
        }

		function removeRedborder(id){
			document.getElementById(id).classList.remove('redBorder');
		}

		function checkAll(){
				var email= document.getElementById('email').value;
				var rtrn = true;
				if (document.getElementById('name').value==''){
					document.getElementById('name').classList.add('redBorder');
					rtrn = false;
				}
				if (document.getElementById('email').value==''){
					document.getElementById('email').classList.add('redBorder');
					rtrn = false;
				}else if(!validateEmail(email)){
					document.getElementById('email').classList.add('redBorder');
					rtrn = false;

				}
				if (document.getElementById('message').value==''){
					document.getElementById('message').classList.add('redBorder');
					rtrn = false;
				}
				return rtrn;
			}
    </script>

</head>
<body>
<div class="wrapper">
    <div class="shell-header">
        <div class="wrap">
            <!--div class="logo">
                <p><font color="#FFFFFF">OnlineQuiz</font></p>
            </div-->
            <nav>
                <a href="index.php"><div class="logo" style="margin-top:0;margin-left:0"></div></a>
             </nav>
            <div class="menu">
                 <nav>
                    <ul>
                        <li><a href="quizLandingPage.php">HOME</a></li>
                        <!--li><a href="about.php">ABOUT US</a></li-->
                        <!--li><a href="contact.php">CONTACT US</a></li-->
                        <!--li><a href="admin\index.php" class="<?php echo ($login?'hide':'show');?>">ADMIN</a></li-->
                        <li><a href="logout.php" class="<?php echo ($login?'show':'hide');?>">LOGOUT</a></li>

                    </ul>
                </nav>
            </div>
        <div class="clearFix"></div>
        </div>
    </div><!--End of header-->
	<div class="shell" style="background-image: linear-gradient(#fff,#fff,#000)">
		<div class="shell-body">
		<center>
		<div class="headLine">
				<img src="images/contact.png" class="heading">
		</div>
		<?php
			if($mailSuccess=='1'){
		?>
		<div class="greenMsgbox">
			<?php echo "Message has been sent successfully. "?>
		</div>
		<?php
			}elseif($mailSuccess=='0'){
		?>
		<div class="redMsgbox">
			<?php echo "Some unknown error has occured. Please try again later. "?>
		</div>


		<?php
			}
		?>
			<div class="contactform">
			<div class="showMsg"><?php echo $msg; ?></div>
			<form class="" id="contactForm" method="post" action="SQLContact.php" onsubmit="return checkAll();">

				<input type="text" id="name" class="inputBox1" name="name" placeholder="Enter Name" onblur='checkNull(id)' required />
				<input type="text" class="inputBox1" name="email" placeholder="Enter Email Address" id="email" onfocus="removeRedborder(id)" onblur='checkNull(id)' required />

				<textarea class="inputBox1" name="message" placeholder="Enter Message" rows="5" id="meassage" onfocus="removeRedborder(id)" onblur='checkNull(id)' required></textarea>


				<input type="submit" class="inputBox1 blueHover " value="Register"  style=""/>

			</form>
			</center>
		</div>
		</center>
		</div>
	</div>
  
       <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>

</div>
</body>
</html>
