<?php
	require_once('connection.php');
	if(!isset($_SESSION['userName'])){
        header("location:index.php");

    }
    else{
        $login=TRUE;
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>TestYourThreshold | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/adminCss.css"/>
	<link rel="stylesheet" type="text/css" href="css/home.css" />
	<script src="js/modernizr.custom.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

	<script>
		function goToPage(id){
			window.location = id+".php";
		}
	</script>
</head>
<body>
<div class="wrapper">
		<div id="header">
  <div class="logo">
  </div>  
  <nav class="navNew">
   <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" > 
      <input name="q" id="searchBox" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
      <li class="liNew">
        <a href="home.php" class="aNew">Home</a>
      </li>
      
        </ul>        
      </li>
      <li class="dropdown liNew">
        <a href="logout.php" class="aNew">LogOut</a>
       
      </li>
     
    </ul>
  </nav>
</div><!--End Of Header-->

	<div class="mainHomeBody" style="background-image: linear-gradient(#000,#404040,#3c3c3c,#000)">
		<div class="wrap">
			<ul class="grid cs-style">
				
				<li>
					<figure>
						<img src="images/1.png">
						<figcaption>
							<h3>Subjects</h3>
							<span>Add/Edit a Subject</span>
							<a href="subject.php">Proceed</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/2.png">
						<figcaption>
							<h3>Tests</h3>
							<span>Add test to Subject</span>
							<a href="test.php">Proceed</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/3.png">
						<figcaption>
							<h3>Questions</h3>
							<span>Add/Edit Question</span>
							<a href="question.php">Proceed</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="images/4.png">
						<figcaption>
							<h3>Credentials</h3>
							<span>Want to change password?</span>
							<a href="changePassword.php">Proceed</a>
						</figcaption>
					</figure>
				</li>
				
			</ul>
		</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3><br>
 
       
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
	
</div><!--End of wrapper-->
</body>
</html>
