<?php

include 'connection.php';
$errorMsg = '';
if(isset($_GET['action'])){
	if(base64_decode(urldecode($_GET['action']))== 'invalidId'){
		$errorMsg = 'Invaild Login Details';

	}
}
if(isset($_GET['action'])){
	if(base64_decode(urldecode($_GET['action']))== 'forgotPass'){
		$errorMsg = 'We have sent instructions to your mail. Please check your Inbox!!!';

	}
}
$sql = "select * from mst_admin";
if(mysqli_num_rows(mysqli_query($con,$sql)) <1){
	$needRegister = true;
}
else{
	$needRegister = false;

}

?>
<!DOCTYPE html>
<html>
<head>
	<title>TestYourThreshold | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/adminCss.css"/>
	<link rel="stylesheet" type="text/css" href="css/adminLogin.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

	<script>
		window.onload = function()
       { 
            const signInButton = document.getElementById('signIn');
            const container = document.getElementById('container');

            signInButton.addEventListener('click', () => {
                container.classList.add('right-panel-active');
            });

           
        }  
        
         function checkMailPhone(){
        var userName=$("#userName").val();
        $.ajax({
            type:'post',
                url:'emailPhoneExists.php',
                data:{userName: userName},
                success:function(msg){
                 if(msg=='mExists'){
                  document.getElementById('checkEP').innerHTML="";
                }
                else if(msg=='notOK'){
                document.getElementById('userName').classList.add('redBorder');
              alert("Please enter a valid UserName!!!");
                $("#userName").val('');
                }
                 
                }
         });
        }
          $(document).ready(function() {


$("#forgotPwd").click(function(){

    $(".sign-in-container").toggleClass("forgot");

});


});
        function SwitchButtons(buttonId) {
  var hideBtn, showBtn;
  if (buttonId == 'button1') {
    showBtn = 'button2';
    hideBtn = 'button1';
    
  } else {
   
    showBtn = 'button1';
    hideBtn = 'button2';
  }
  
  document.getElementById(hideBtn).style.display = 'none'; 
  document.getElementById(showBtn).style.display = ''; 


}
         function showLoginPass() {
          var x = document.getElementById("password");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
		document.getElementsByTagName('input').click = function(){
			alert("NULL");
		}
		function checkNull(id){

            if (document.getElementById(id).value==''){
                document.getElementById(id).classList.add('redBorder');
                return false;
            }
            else{
                document.getElementById(id).classList.remove('redBorder');
                return true;
            }
        }
		function checkAll(){
		var rtrn = true;
		if (document.getElementById('userName').value==''){
				document.getElementById('userName').classList.add('redBorder');
				rtrn = false;
			}
		if (document.getElementById('password').value==''){
				document.getElementById('password').classList.add('redBorder');
				rtrn = false;
			}
		return rtrn;
		}
	</script> 
</head>
<body>
<div class="wrapper">
	<div id="header">
  <div class="logo">
  </div>  
  <nav class="navNew">
    <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" > 
      <input name="q" id="searchBox" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
      <li class="liNew">
        <a href="../index.php" class="aNew">Home</a>
      </li>
      
        </ul>        
      </li>
      
    </ul>
  </nav>
</div>
<!--End Of Header-->

	<div class="loginBody" style="background-image: linear-gradient(#000,#4a4949,#424040,#000)">
	<div class="wrap">
			<center>
					<!--h1 class="heading deepYellow" style="margin-top:30px">
							TYT Admin Panel
						</h1-->

			<?php
			if($errorMsg == 'Invaild Login Details')
			{
			?>
				<p class="redMsgbox">Invaild Login Details</p>
			<?php
			}else if($errorMsg =='We have sent instructions to your mail. Please check your Inbox!!!'){
			?>
			<p class="redMsgbox">We have sent instructions to your mail. Please check your Inbox!!!</p>
			<?php
			}
			?>

			<div class="container" id="container">
			<div class="form-container sign-in-container">
                       
                    
                        
                        <form class="logregform" name="loginForm" id="loginForm" method="post" >
                           
                             <h2><span style="margin-bottom:6px" class="spanSwitch">Admin Sign In</span>  <span  class="spanSwitch">Recover My Password</span></h2>

                            <div class="social-container">
                                <a href="https://www.facebook.com/" class="social-fb"><i class="fa fa-facebook"></i></a>
                                <a href= "https://www.google.com/" class="social-google"><i class="fa fa-google"></i></a>
                                <a href="https://www.linkedin.com/" class="social-li"><i class="fa fa-linkedin"></i></a>
                            </div>
                            <h4 style="margin-bottom:20px">Or use your account</h4>
                            
                                 <!--input type="email" placeholder="Email" /-->
                            <input type="text"  name="userName" id="userName" placeholder="Enter Username or Email ID" onfocus="removeRedborder(id)" onblur="checkMailPhone(); checkNull(id);" required="required"/>
                            <span  class="fa fa-envelope icon"></span>
                            <!--input type="password" placeholder="Password" /-->
                            <input type="password"  name="password" id="password" placeholder="Enter Password"  class="password" onfocus="removeRedborder(id)" onblur="checkNull(id)" autocomplete="off" />

                             <span  class="fa fa-eye field-icon password" onclick="showLoginPass()"></span>
                            <br/>
                            <a id="forgotPwd"><span onclick="SwitchButtons('button1');"  class="spanSwitch" style="color: #1063DD">Forgot password ?</span>

                            <span onclick="SwitchButtons('button2');" class="spanSwitch" style="color: #1063DD">Oh I remembered!</span></a>
                             
                             <button id="button1" formaction="SQLlogin.php" onclick="return checkAll();" class="logregbutton">SIGN IN</button>
                             <button id="button2" formaction="mail.php" class="logregbutton" style='display:none;'>GET Password</button>
                            
                        </form>
                    
                    </div>
                   
                    <div class="overlay-container">
               
                        <div class="overlay">
                          
                            <div class="overlay-panel overlay-right">

                            <h1>Welcome To</h1></br>
                                <!--p style="font-size:15px"><b>To keep connected with us please login with your personal info.</b></p-->
                                <h3>TestYour<span>Threshold</span></h3>
                                <!--h4 style="font-size:25px">Admin Panel</h4-->
                            <!--button class="ghost" id="signUp">Sign Up</button-->
                            <input type="submit" id="signIn" class=" overlayButton" value="Sign In  &nbsp&gt&gt">
                        </div>
                    </div>
                </div>
			</center>
			<div class="clearFix"></div>
		</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3><br>
                <p class="footer-links">
                    <a href="index.php">Home</a>
                    |
                    <a href="../login.php">User Login</a>
                    |
                    <a href="../about.php">About Us</a>
                    |
                    <a href="../contact.php">Contact Us</a>
                </p>
       
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>

</div><!--End of Wrapper-->
</body>
</html>
