<?php

     if ( $_SERVER['REQUEST_METHOD']!='POST' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
     
    
        die( header( 'location: error.php' ) );

    }
    
    require_once('connection.php');
   
   $userName = $_POST['userName'];
		$sql = "SELECT * FROM mst_admin WHERE login_user ='".$userName."'";
		$result = mysqli_query($con,$sql);
		
			if(mysqli_num_rows($result) >0){
				 echo 'mExists';
			}
			else{
				
				echo 'notOK';
			}
		
		
	
   
   
   
?>
