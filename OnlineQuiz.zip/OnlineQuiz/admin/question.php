<?php
require_once('connection.php');
	if(!isset($_SESSION['userName'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
	$subjectSql = "SELECT * FROM mst_subject WHERE enable = 1";
	$subjectResult=mysqli_query($con,$subjectSql);
	if(isset($_GET['sid'])&&(!isset($_GET['tid'])))
	{
		$sid=$_GET['sid'];
		$showTest = true;
		$sql = "SELECT * FROM mst_test where enable=1 AND sub_id=(SELECT id FROM mst_subject WHERE id = '".$_GET['sid']."' AND enable=1) order by test_name";
		$result = mysqli_query($con,$sql);
	}
	else{
		$sid='';
		$showTest = false;
	}
    if(isset($_GET['sid'])&&isset($_GET['tid'])){
        $questionCountSQL = "SELECT total_question FROM mst_test WHERE id = '".$_GET['tid']."'";
        $questionCountResult = mysqli_query($con,$questionCountSQL);
        $totalQuestion = mysqli_fetch_assoc($questionCountResult);
        $showQuestion=true;
        $questionSql = "SELECT * FROM mst_question WHERE enable=1 AND test_id = '".$_GET['tid']."'";
        $allQuestion = mysqli_query($con,$questionSql);

    }
    else{
        $showQuestion = false;
    }
    $randColor=array('#9C27B0','#00CC00','#663300','#FF6600','#0288D1','#FF00FF');
?>
<!DOCTYPE html>
<html>
<head>
	<title>OnlineQuiz | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/adminCss.css"/>
	<link rel="stylesheet" type="text/css" href="css/shell.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"-->

	<meta name="viewport" content="width=device-width,initial-scale=1.0">
    <script>
        window.onload=function (){
        var subjectBox = document.getElementById('subjectName');
        var testBox = document.getElementById('testName');
            subjectBox.value = '<?php
                                if(isset($_GET['sid']))
                                {
                                    echo $_GET['sid'];
                                }
                                ?>';
            testBox.value = '<?php
                                if(isset($_GET['tid']))
                                {
                                    echo $_GET['tid'];
                                }
                                ?>';
        };
        
       
        function selectSubject(){
			if(document.getElementById("subjectName").value != ''){

				document.getElementById("selectSubjectForm").submit();

			}

		}
        function edit(id){
            var qusid = id.split('_')
            document.getElementById("saveChange").style.display='block';
            document.getElementById('qus_'+qusid[1]).removeAttribute('readonly');
            document.getElementById('ans1_'+qusid[1]).removeAttribute('readonly');
            document.getElementById('ans2_'+qusid[1]).removeAttribute('readonly');
            document.getElementById('ans3_'+qusid[1]).removeAttribute('readonly');
            document.getElementById('ans4_'+qusid[1]).removeAttribute('readonly');
            document.getElementById('correct_'+qusid[1]).removeAttribute('readonly');
        }
        function del(id){
           var qusid = id.split('_');
           /*var Id = '<?php echo $sid; ?>';*/

				var confirm = window.confirm("Are you sure to delete this Question?");
				if(confirm){
					window.location = "SQLquestion.php?action=del&<?php echo 'sid='.$_GET['sid'].'&tid='.$_GET['tid'];  ?>&qid="+qusid[1];
				}
        }
        function saveChange(){
            document.getElementById('qustion').submit();
        }

    </script>
</head>
<body>
<div class="wrapper">
	<div id="header">
  <div class="logo">
  </div>  
  <nav class="navNew">
  <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" > 
      <input name="q" id="searchBox" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
      <li class="liNew">
        <a href="home.php" class="aNew">Home</a>
      </li>
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew" style="width:190%">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="subject.php">Subjects</a></li>
            </ul>
            <ul class="mega-col ulNew">
              <li class="liNew"><a href="test.php">Tests</a></li>
          
            </ul>
            <ul class="mega-col">
              <li class="liNew"><a href="question.php">Questions</a></li>
           
            </ul>
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php">LogOut</a></li>
             
            </ul>
          </li>
        </ul>        
      </li>
   
     
    </ul>
  </nav>
</div> <!--End Of Header--><div class="shell" style="background-image: linear-gradient(#FFEBEE,#000)">
		<div class="shell-body">
			<div class="heading lightYellow" style="font-size:170%;">Choose a Subject</div>
            <!--<hr style="border-color:#F2F2F2; margin-bottom:1vh;"/>-->
			<center>
			<div class="addNewBox">
				<form method="get" action="question.php" id="selectSubjectForm">
				
					<label for="subjectName" class="select">
				
						<select name="sid" id="subjectName">
						<option value="" disabled hidden>SELECT SUBJECT</option>
					<?php
						while($eachSubject = mysqli_fetch_assoc($subjectResult))
						{
							echo "<option value='".$eachSubject['id']."'>".$eachSubject['sub_name']."</option>";

						}

					?>
					</select>
					</label>
					
                    <br/>
                    <?php
                        if($showTest){
                    ?>
                    <div class="heading lightYellow" style="font-size:170%;">Choose a Test</div>
                    <label for="testName" class="select">
				<select name="tid" id="testName">
						<option value="" disabled hidden>SELECT Test</option>
					<?php
						while($eachTest = mysqli_fetch_assoc($result))
						{
							echo "<option value='".$eachTest['id']."'>".$eachTest['test_name']."</option>";
						}
					?>
					</select>		
					</label>
					
					<?php
                        }
                    ?>
				</form>


			</div>

			<button style="--bg: hsl(37, 16%, 90%), hsl(208, 29%, 73%), hsl(205, 58%, 34%)">
    			<span class="spanSubmit" style="--ic: hsl(208, 49%, 93%)" onclick="selectSubject()">Submit</span>
  			</button>

			<div class="clearFix"></div>
			<?php
				if($showQuestion){
			?>
			<div class="questionList">
                <p style="font-size:4vh;" class="skyBlue">Question List</p></br>
            <form id="qustion" method="post" action="SQLquestion.php?action=edit&<?php echo 'sid='.$_GET['sid'].'&tid='.$_GET['tid'];  ?>">
				<table class="questionList" border="0">
				<?php
					if(($questionCount = mysqli_num_rows($allQuestion))>0){
						while($row=mysqli_fetch_assoc($allQuestion)){
                ?>

                    <tr class="tableCol">
                        <td><input name='qid[]' value="<?php echo $row['id'];?>" hidden="hidden">
                            <input  readonly class="question_box quizFormQus" type="text" name="qus[]" id="<?php echo "qus_".$row['id'];?>" value="<?php echo $row['ques_details']; ?>" required></td>

                        <!--td class="" rowspan="5"><input type="button" class="" id="edit_<?php echo $row['id'];?>" value="Edit" onclick="edit(id)">
                        <input type="button" class="" id="del_<?php echo $row['id'];?>" value="Delete" onclick="del(id)"-->
                        <!--button id="edit_<?php echo $row['id'];?>" onclick="goToPage(id)" class="btn btn-success btn-sm rounded-0" type="button" title="Edit"><i class="fa fa-edit"></i></button>
                            <button id="del_<?php echo $row['id'];?>" onclick="goToPage(id)" class="btn btn-danger btn-sm rounded-0" type="button" title="Delete"><i class="fa fa-trash"></i></button>
                        </td-->
                    </tr>

                    <tr><td><input readonly class="question_box quizFormAns" type="text" name="ans1[]" id="<?php echo "ans1_".$row['id'];?>" value="<?php echo $row['ans1']; ?>" required></td></tr>
                    <tr><td><input  readonly class="question_box quizFormAns" type="text" name="ans2[]" id="<?php echo "ans2_".$row['id'];?>" value="<?php echo $row['ans2']; ?>" required></td></tr>
                    <tr><td><input  readonly class="question_box quizFormAns" type="text" name="ans3[]" id="<?php echo "ans3_".$row['id'];?>" value="<?php echo $row['ans3']; ?>" required></td></tr>
                    <tr><td><input  readonly class="question_box quizFormAns" type="text" name="ans4[]" id="<?php echo "ans4_".$row['id'];?>" value="<?php echo $row['ans4']; ?>" required></td></tr>

                     <tr><td><span style="color:#4EB509">Correct Ans: &nbsp </span><input  readonly class="question_box" style="width: 30vw;" type="number" max="4" min="1" name="correct[]" id="<?php echo "correct_".$row['id'];?>" value="<?php echo $row['correct_ans']; ?>" required>

                            <button id="edit_<?php echo $row['id'];?>" onclick="edit(id)" class="btn btn-success btn-sm rounded-0" type="button" title="Edit"><i class="fa fa-edit"></i></button>
                            <button id="del_<?php echo $row['id'];?>" onclick="del(id)" class="btn btn-danger btn-sm rounded-0" type="button" title="Delete"><i class="fa fa-trash"></i></button></td>
                        </tr>



                <?php
                        }
                ?>
				</table>
				<button style="--bg: hsl(37, 16%, 90%), hsl(208, 29%, 73%), hsl(205, 58%, 34%)">
                <span type="submit" class="spanSubmit" style="--ic: hsl(208, 49%, 93%)" id="saveChange" onclick="saveChange()">Save Changes
                </span></button>


                <?php

                    }else
                        echo "<p style='color:#EE2828;font-size:4vh'>No Question Found</p>";

				?>

            </form>
			</div>

			<div class="addQuestionBox">
                <?php
                    if(($addQusCount = $totalQuestion['total_question'] - $questionCount)>0){
                ?>
                <p style="font-size:4vh;" class="skyBlue">Add Question</p>
				<form method="post" action="SQLquestion.php?action=addNew&<?php echo 'sid='.$_GET['sid'].'&tid='.$_GET['tid'];?>" id="addNewForm">
				<?php
                    for($i=0;$i<$addQusCount;$i++){
                ?>
                    <table border="0" style="margin:4vh 0 4vh 0;">
                    <tr class="tableCol">
                    <td>
                        <label for="question" class="yellowBorder">
						Question
					   </label>
                    </td>
                    <td><input class="question_box" type="text" name="qus[]" id="<?php echo "qus_".$row['id'];?>" value="<?php echo $row['ques_details']; ?>" required></td>
                    </tr>

                    <tr>
                    <td>
                        <label for="ans1" class="yellowBorder">
						Option 1
					   </label>
                    </td>
                    <td><input  class="question_box" type="text" name="ans1[]" id="<?php echo "ans1_".$row['id'];?>" value="<?php echo $row['ans1']; ?>" required></td></tr>
                    <tr>
                    <td>
                        <label for="ans2" class="yellowBorder">
						Option 2
					   </label>
                    </td>
                    <td><input   class="question_box" type="text" name="ans2[]" id="<?php echo "ans2_".$row['id'];?>" value="<?php echo $row['ans2']; ?>" required></td></tr>
                    <tr>
                    <td>
                        <label for="ans3" class="yellowBorder">
						Option 3
					   </label>
                    </td>
                    <td><input   class="question_box" type="text" name="ans3[]" id="<?php echo "ans3_".$row['id'];?>" value="<?php echo $row['ans3']; ?>" required></td></tr>
                    <tr>
                    <td>
                        <label for="ans4" class="yellowBorder">
						Option 4
					   </label>
                    </td>
                    <td><input   class="question_box" type="text" name="ans4[]" id="<?php echo "ans4_".$row['id'];?>" value="<?php echo $row['ans4']; ?>" required></td></tr>

                     <tr>
                    <td>
                        <label for="ans1" class="yellowBorder">
                            <span style="color:#4EB509">Correct Ans:</span>
                        </label>
                    </td>
                    <td><input  class="question_box" style="width: 30vw;" type="number" max="4" min="1" name="correct[]" id="<?php echo "correct_".$row['id'];?>" value="<?php echo $row['correct_ans']; ?>" required></td></tr>

				    </table>

                <?php

                    }
                ?>
                
                <button style="--bg: hsl(37, 16%, 90%), hsl(208, 29%, 73%), hsl(205, 58%, 34%)">
    			<span type="submit" class="spanSubmit" style="--ic: hsl(208, 49%, 93%)" onclick="addNewTest()">Add New Questions</span>
  			</button>
				
				</form>
            <?php
                    }
            ?>
            </div>

			<?php

                }
			?>
	
                </div>

	</center>
   
     
  
	</div>
   <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3><br>
 
       
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div><!--End of wrapper-->
</body>
</html>
