<?php
if ( $_SERVER['REQUEST_METHOD']!='POST' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
     
    
        die( header( 'location: error.php' ) );

    }

$userName = $_POST['userName'];
require_once('connection.php');
function getRandomBytes($nbBytes = 32){

    $bytes = openssl_random_pseudo_bytes($nbBytes, $strong);

    if (false !== $bytes && true === $strong) {

        return $bytes;

    }

    else {

        throw new \Exception("Unable to generate secure token from OpenSSL.");

    }

}

function generatePassword($length){

    return substr(preg_replace("/[^a-zA-Z0-9]/", "", base64_encode(getRandomBytes($length+1))),0,$length);

}
    $random_password = generatePassword(10);  
    $password = md5($random_password); 


$password = md5($random_password); 

$checkSql1 = "UPDATE mst_admin SET login_pass='$password' WHERE login_user='$userName'"; 

$result= mysqli_query($con,$checkSql1);
use \PHPMailer\PHPMailer\PHPMailer;
use \PHPMailer\PHPMailer\SMTP;
use \PHPMailer\PHPMailer\Exception;


require '../vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    
    $mail->SMTPDebug = FALSE;                      
    $mail->isSMTP();                                          
    $mail->Host       = 'smtp.gmail.com';                   
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'TestYourThreshold@gmail.com';                     
    $mail->Password   = 'rncrl1@NF';                               
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
    $mail->Port       = 587;                                    

    //Recipients
    $mail->setFrom('donotreply.tyt@gmail.com', 'TestYourThreshold');
    $mail->addAddress($userName, 'Admin');     
  

    // Content
    $mail->isHTML(true);                                  
    $mail->Subject = 'Reset Your Password';
    $mail->Body    ="Thanks a lot for contacting us.Your Temporary Password is :<b><i> $random_password </i></b>.
                     Login using this password and change your password after login.
                     Best Of Luck!!"
       
       ;
       
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    if($mail->send())
{
    // echo 'Message has been sent';
    header("location:index.php?action=".urlencode(base64_encode('forgotPass')));
  }  
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


?>
