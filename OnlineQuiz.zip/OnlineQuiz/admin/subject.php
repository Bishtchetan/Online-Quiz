<?php
	require_once('connection.php');
	if(!isset($_SESSION['userName'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }

	$sql = "SELECT * FROM mst_subject where enable = 1 order by sub_name";
	$result = mysqli_query($con,$sql);
	$randColor=array('#9C27B0','#00CC00','#663300','#FF6600','#0288D1','#FF00FF');

?>
<!DOCTYPE html>
<html>
<head>
	<title>TestYourThreshold | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="css/adminCss.css"/>
	<link rel="stylesheet" type="text/css" href="css/shell.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"-->
	<meta name="viewport" content="width=device-width,initial-scale=1.0">

	<script>
		
		function goToPage(id){
			var	array= id.split('_');
			if(array[0]=='edit'){

				document.getElementById('editDiv').classList.add('expand');

				document.getElementById('editSubName').value=document.getElementById('subName'+array[1]).innerHTML;

				document.getElementById('editSubId').value = array[1];

				document.getElementById('editDiv').scrollIntoView();
			}else if(array[0]=='del'){
				var subName = document.getElementById('subName'+array[1]).innerHTML;
				var confirm = window.confirm("Are you sure to delete "+subName+"\n(All it's test will be deleted)");
				if(confirm){
					window.location = "SQLsubject.php?action=del&subId="+array[1];
				}
			}
		}
		function addNewSubject(){
			if(document.getElementById("subjectName").value != ''){

				document.getElementById("addNew").submit();

			}

		}
	</script>
</head>
<body>
<div class="wrapper">
	<div id="header">
  <div class="logo">
  </div>  
  <nav class="navNew">
  <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" > 
      <input name="q" id="searchBox" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
      <li class="liNew">
        <a href="home.php" class="aNew">Home</a>
      </li>
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew" style="width:190%">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="subject.php">Subjects</a></li>
            </ul>
            <ul class="mega-col ulNew">
              <li class="liNew"><a href="test.php">Tests</a></li>
          
            </ul>
            <ul class="mega-col">
              <li class="liNew"><a href="question.php">Questions</a></li>
           
            </ul>
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php">LogOut</a></li>
             
            </ul>
          </li>
        </ul>        
      </li>
   
     
    </ul>
  </nav>
</div> <!--End Of Header-->

	<div style="background-image: linear-gradient(#FFEBEE,#000)" class="shell">
		<div class="shell-body">
			
			<div class="heading lightYellow">Subjects</div>
<!--			<hr style="border-color:#F2F2F2; margin-bottom:1vh;"/>-->

			<center>
			<div class="addNewBox">
				<form method="post" action="SQLsubject.php?action=addNew" id="addNew">
					
					<input type="text" placeholder="Subject Name" autocomplete="off" class="txtSearch" id="subjectName" name="subjectName" style="margin:0 3% 3% 3%;"/>
				</form>

			
			<div>
			<button style="--bg: hsl(37, 16%, 90%), hsl(208, 29%, 73%), hsl(205, 58%, 34%)">
						<span class="spanSubmit" style="--ic: hsl(208, 49%, 93%)"onclick="addNewSubject()">Add New Subject</span>
  					</button></div>
			</div>
			<div class="clearFix"></div>
			<div class="subjectList">
				<table class="tableNew">
				<tbody>
				<thead class="theadNew"> 
				<tr class="table-head trNew">
<!--					<th>ID</th>-->
					<th class="thNew">Subject Name</th>
					<th class="thNew">No of test</th>
					<th class="thNew">Option</th>
				</tr></thead>
				<?php

					while($row=mysqli_fetch_assoc($result)){
						$count = mysqli_num_rows(mysqli_query($con,"SELECT * FROM mst_test WHERE enable=1 AND sub_id =".$row['id']));
						echo "<tr class='tableRow trNew'>"	;
//						echo "<td class='tableCol' id='id".$row['id']."'>".$row['id']."</td>";
						echo "<td class='tableCol tdNew' id='subName".$row['id']."'>".$row['sub_name']."</td>";
						echo "<td class='tableCol tdNew'>".$count."</td>";
				?>
						<td class="tableCol tdNew">
						<button id="edit_<?php echo $row['id'];?>" onclick="goToPage(id)" class="btn btn-success btn-sm rounded-0" type="button" title="Edit"><i class="fa fa-edit"></i></button>
                        <button id="del_<?php echo $row['id'];?>" onclick="goToPage(id)" class="btn btn-danger btn-sm rounded-0" type="button" title="Delete"><i class="fa fa-trash"></i></button>    	                    
						<!--input type="button" class="" id="edit_<?php echo $row['id'];?>" value="Edit" onclick="goToPage(id)">
						<input type="button" class="" id="del_<?php echo $row['id'];?>" value="Delete" onclick="goToPage(id)"-->
						</td>

				<?php
						echo "</tr>";

					}
				?>
				</tbody>
				</table>
			</div>
			<div class="editDiv" id=editDiv>
				<img src="images/close.png" class="right" onclick="document.getElementById('editDiv').classList.remove('expand');" style="cursor:pointer;">
				<label for="subjectName" class="yellowBorder">
						Edit Subject Name
				</label>
				<form method="post" action="SQLsubject.php?action=edit">
					<input type="text" name="sub_id" id="editSubId" hidden="hidden" readonly />
					<input type="text" name= "sub_name" id="editSubName" class="inputBox1 bottomBorder yellowBorder yellowFocus" placeholder="Edit Subject" />
					<div>
					<button style="--bg: hsl(37, 16%, 90%), hsl(208, 29%, 73%), hsl(205, 58%, 34%)">
						<span class="spanSubmit" style="--ic: hsl(208, 49%, 93%)">SAVE</span>
  					</button>
  					</div>
					<!--input type="submit" class="spanSubmit" value="SAVE"/-->
				</form>
			</div>


	</center>
	
		
	</div>
	</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3><br>
 
       
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
	
</div><!--End of wrapper-->
</body>
</html>
