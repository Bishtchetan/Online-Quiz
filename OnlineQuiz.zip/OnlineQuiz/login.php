<?php
    include 'connection.php';
    if(isset($_SESSION['email'])){
        header("location:quizLandingPage.php");
    }
    else{
 
    }
    $msgs='';
    $msg ='';  
    if(isset($_GET['action'])){
        $action= base64_decode(urldecode($_GET['action']));
        switch($action){
            case 'invalidId':
                    $msg="<font color='#F6111D'>Invalid Email Id or Password</font>";
                    break;
            case 'loggedOut':
                    $msg="<font color='#3193F5'>Logged Out Successfully</font>";
                    break;
            case 'loggedOutAfterReg':
                    $msg="<font color='#3193F5'>Registeration Successfull !! Please Login.</font>";
                    break;
            case 'notLogin':
                    $msg="<font color='#3193F5'>Login First</font>";
                    break;
            case 'forgotPass':
                    $msg="<font color='#3193F5'>We have sent instructions to your mail !! Please check your mail.</font>";
                    break;                       
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        var redBorder = "border-color:#FE4551;color:#FE4551;box-shadow: 0px 0px 15px 0px rgba(216, 21, 21, 0.70);moz-box-shadow: 0px 0px 15px 0px rgba(216, 21, 21, 0.70);webkit-box-shadow: 0px 0px 15px 0px rgba(216, 21, 21, 0.70);transition:1s;";
        var greyBorder = "trsnsition:1s";

       window.onload = function()
       { 
            const signUpButton = document.getElementById('signUp');
            const signInButton = document.getElementById('signIn');
            const container = document.getElementById('container');

            signUpButton.addEventListener('click', () => {
                container.classList.add('right-panel-active');
            });

            signInButton.addEventListener('click', () => {
                container.classList.remove('right-panel-active');
            });
        }  
  
        function checkMailPhone(){
        var email=$("#email").val();
        var phone=$("#phone").val();
        $.ajax({
            type:'post',
                url:'emailPhoneExists.php',
                data:{email: email, phone: phone},
                success:function(msg){
                 if(msg=='mExists'){
                 document.getElementById('email').classList.add('redBorder');
                 document.getElementById('checkEP').innerHTML="<font color='#F6111D'>Email Id already linked with an account</font>";
                 $("#email").val('');
                }
                else if(msg=='pExists'){
                document.getElementById('phone').classList.add('redBorder');
                document.getElementById('checkEP').innerHTML="<font color='#F6111D'>Phone no already linked with an account</font>";
                $("#phone").val('');
                }
                 else if(msg=='allOK'){
               
                 document.getElementById('checkEP').innerHTML="";
                }
                }
         });
        }
        
        $(document).ready(function() {


        $("#forgotPwd").click(function(){

            $(".sign-in-container").toggleClass("forgot");

        });


        });
                function SwitchButtons(buttonId) {
          var hideBtn, showBtn;
          if (buttonId == 'button1') {
            showBtn = 'button2';
            hideBtn = 'button1';
            
          } else {
           
            showBtn = 'button1';
            hideBtn = 'button2';
          }
          
          document.getElementById(hideBtn).style.display = 'none'; 
          document.getElementById(showBtn).style.display = ''; 


        }
        
        function validateName(name)
        {
            var na= /^[A-Za-z ]+$/;
            return na.test(name);
        }
        function validateEmail(email){
            var re=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }
        function CheckPassword(password) 
        { 
            /* Password should between 6 to 20 char which contains at least one number, one uppercase and one lowercase letter*/
            var pass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
            return pass.test(password);
        }
        function validateCity(city)
        {
            var obj= /^[A-Za-z ]+$/;
            return obj.test(city);
        }
        function isNumber(evt)
        {
             var charCode = (evt.which) ? evt.which : event.keyCode
             if (charCode != 45  && charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

             return true;
        }
       /* function checkNull(id){

            if (document.getElementById(id).value==''){
                document.getElementById(id).style.cssText=redBorder;
                return false;
            }
            else{
                document.getElementById(id).style.cssText='';
                return true;
            }
        }*/
        function checkNull(id){

            if (document.getElementById(id).value==''){
                document.getElementById(id).classList.add('redBorder');
                return false;
            }
            else{
                document.getElementById(id).classList.remove('redBorder');
                return true;
            }
        }
        function showPass() {
          var x = document.getElementById("password");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        function showLoginPass() {
          var x = document.getElementById("pass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }

        function removeRedborder(id){
            document.getElementById(id).classList.remove('redBorder');
        }

        function checkAll(){
            var email= document.getElementById('emailid').value;
            var rtrn = true;
//            if (document.getElementById('name').value==''){
//                document.getElementById('name').style.cssText=redBorder;
//                rtrn = false;
//            }
            if (document.getElementById('emailid').value==''){
                document.getElementById('emailid').classList.add('redBorder');
                rtrn = false;
            }else if(!validateEmail(email)){
                document.getElementById('emailid').classList.add('redBorder');
                rtrn = false;

            }

            if (document.getElementById('pass').value==''){
                document.getElementById('pass').classList.add('redBorder');
                rtrn = false;
            }
//            if (document.getElementById('address').value==''){
//                document.getElementById('address').style.cssText=redBorder;
//                rtrn = false;
//            }
//            if (document.getElementById('city').value==''){
//                document.getElementById('city').style.cssText=redBorder;
//                rtrn = false;
//            }
//            if (document.getElementById('phone').value==''){
//                document.getElementById('phone').style.cssText=redBorder;
//                rtrn = false;
//            }
           return rtrn;
        }
        function checkAllData(){
            var email= document.getElementById('email').value;
            var password= document.getElementById('password').value;
            var name= document.getElementById('name').value;
            var city= document.getElementById('city').value;
            var rtrn = true;

            if (document.getElementById('name').value==''){
                document.getElementById('name').classList.add('redBorder');
                rtrn = false;
            }else if(!validateName(name)){
                document.getElementById('name').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('email').value==''){
                document.getElementById('email').classList.add('redBorder');
                rtrn = false;
            }else if(!validateEmail(email)){
                document.getElementById('email').classList.add('redBorder');
                rtrn = false;

            }

            if (document.getElementById('password').value==''){
                document.getElementById('password').classList.add('redBorder');
                rtrn = false;
            }else if(!CheckPassword(password)){
                document.getElementById('password').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('address').value==''){
                document.getElementById('address').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('city').value==''){
                document.getElementById('city').classList.add('redBorder');
                rtrn = false;
            }else if(!validateCity(city)){
                document.getElementById('city').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('phone').value=='' || document.getElementById('phone').value.length < 10){
                document.getElementById('phone').classList.add('redBorder');
                rtrn = false;
            }
           return rtrn;
        }

    </script>
</head>
<body>
<div class="wrapper">
    <div class="header">
        <div class="wrap">
            <nav>
                <a href="index.php"><div class="logo" style="margin-top:0;margin-left:0"></div></a>
             </nav>
            <!--div class="logo">
                <p><font color="#FFFFFF">OnlineQuiz</font></p>
            </div-->
            <div class="menu">
                 <nav>
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="about.php">ABOUT US</a></li>
                        <!--li><a href="contact.php">CONTACT US</a></li-->
                        <li><a href="login.php" class="<?php echo ($login?'hide':'show');?>">LOGIN</a></li>
                        <!--li><a href="admin\index.php" class="<?php echo ($login?'hide':'show');?>">ADMIN</a></li-->
                        <li><a href="logout.php" class="<?php echo ($login?'show':'hide');?>">LOGOUT</a></li>
                    </ul>
                </nav>
            </div>
        <div class="clearFix"></div>
        </div>
    </div><!--End of header-->






    <div style="background-image: linear-gradient(#000,#3e3838,#514f4f,#000)" class="mainBody" >
        <div class="wrap">
            <center>
                <div class="container" id="container">

                    <div class="form-container sign-up-container">
                        
                        
                        <form class="logregform" autocomplete="off" class="" id="signUpForm" method="post" action="SQLRegister.php" onsubmit="return checkAllData();">
                            <div class="showMsg" id="checkEP"></div>
                            <h1 style="font-family:Montserrat">Create Account</h1>
                            <div class="social-container">
                                <a href="https://www.facebook.com/" class="social-fb"><i class="fa fa-facebook-f"></i></a>
                                <a href= "https://www.google.com/" class="social-google"><i class="fa fa-google"></i></a>
                                <a href= "https://www.linkedin.com/" class="social-li"><i class="fa fa-linkedin"></i></a>
                            </div>
                            
                            <input type="text" id="name"  name="name" placeholder="Enter Name" onfocus="removeRedborder(id)" onblur='checkNull(id)'/>
                            <span  class="fa fa-user icon"></span>

                            <input type="text" size=10 maxlength=10 name="phone" placeholder="Enter Phone No" id="phone" onblur='checkMailPhone(); checkNull(id)' onfocus="removeRedborder(id)" onkeypress='return isNumber(event)'/>
                            <span  class="fa fa-phone icon"></span>

                            <input type="text"  name="email" placeholder="Enter Email" id="email" onfocus="removeRedborder(id)" onblur='checkMailPhone(); checkNull(id)'/>     	 <div tooltip="Please enter a valid email address (Ex: tyt@tyt.com)" >
                             <span  class="fa fa-envelope icon"></span></div>

                            <input type="password" name="password" placeholder="Enter password" onfocus="removeRedborder(id)"  id="password" onblur='checkNull(id)'/>
                            <div tooltip="Minimum 6 characters(1 Uppercase, 1 Lowercase & 1 Digit)" >
                            <span  class="fa fa-eye field-icon" onclick="showPass()"></span>
                           
                            <!--input type="checkbox" onclick="showPass()">Show Password-->
                            </div>

                            <input type="textarea" name="address" placeholder="Enter Address" rows="5" id="address" onfocus="removeRedborder(id)" onblur='checkNull(id)'/>
                            <span  class="fa fa-address-card icon"></span>

                            <input type="text"  name="city" placeholder="Enter City" id="city" onfocus="removeRedborder(id)" onblur='checkNull(id)'/>
                            <span  class="fa fa-map-marker icon"></span>

                            <input type="submit" class=" logregbutton" value="Sign Up">
                            <!--button>Sign Up</button-->
                        </form>
                    </div>

                    
                    <div class="form-container sign-in-container">
                        
                        <form class="logregform" name="loginForm" id="loginForm" method="post" >
                            <div class="showMsg"><?php echo $msg; ?></div>
                             <h2><span class="spanSwitch">Sign In</span>  <span style="margin-top:5px "class="spanSwitch">Recover My Password</span></h2>
                            <div class="social-container">
                                <a href="https://www.facebook.com/" class="social-fb"><i class="fa fa-facebook"></i></a>
                                <a href= "https://www.google.com/" class="social-google"><i class="fa fa-google"></i></a>
                                <a href="https://www.linkedin.com/" class="social-li"><i class="fa fa-linkedin"></i></a>
                            </div>
                            <h3 style="font-family: Montserrat; font-size: 12px">Or use your account</h3></br>
                            
                                 <!--input type="email" placeholder="Email" /-->
                            <input type="text"  name="email" id="emailid" placeholder="Enter Email Address" autocomplete="off" class="username" onfocus="removeRedborder(id)" onblur="checkNull(id)" required="required"/>
                            <span  class="fa fa-envelope icon"></span>
                            <!--input type="password" placeholder="Password" /-->
                            <input type="password"  name="password" id="pass" placeholder="Enter Password"  class="password" onfocus="removeRedborder(id)" onblur="checkNull(id)" autocomplete="off" />

                             <span  class="fa fa-eye field-icon password" onclick="showLoginPass()"></span>
                            <br/>
                            <a id="forgotPwd"><span onclick="SwitchButtons('button1');"  class="spanSwitch" style="color: #1063DD">Forgot password ?</span>

                            <span onclick="SwitchButtons('button2');" class="spanSwitch" style="color: #1063DD">Oh I remembered!</span></a>
                             
                             <button id="button1" formaction="SQLLogin.php" onclick="return checkAll();" class="logregbutton">SIGN IN</button>
			                 <button id="button2" formaction="mail.php" class="logregbutton" style='display:none;'>Get Password</button>
                             <!--button>Log In</button-->
                            <!--button>Sign In</button-->
                            <!--h5 style="color:#F44336; margin-top:12px ">Red box shows ERROR !! Please enter valid data.</h5-->
                        </form>
                    </div>
                   
                    <div class="overlay-container">
               
                        <div class="overlay">
                            <div class="overlay-panel overlay-left">
                                <h1 style="font-family: Montserrat;" >Welcome Back!</h1></br>
                                <p style="font-size:13px;font-family:Montserrat;";><b>To keep connected with us please login with your personal info.</b></p>
                                 <input type="submit" id="signIn" class="overlayButton" value=" &lt&lt&nbsp Sign In">
                                <!--button class="ghost" id="signIn">Sign In</button-->
                            </div>
                            <div class="overlay-panel overlay-right">
                            <h1 style="top:50px;font-family: Montserrat; ">Hello, Friend!</h1></br>
                            <p style="font-size:15px; font-family: Montserrat;"><b>Enter your personal details and spread your wings.</b></p>
                            <!--button class="ghost" id="signUp">Sign Up</button-->
                            <input type="submit" id="signUp" class=" overlayButton" value="Sign Up  &nbsp&gt&gt">
                        </div>
                    </div>
                </div>
            </center>
        </div>
    </div><!--End of Main Body-->        
        
    <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="index.php">Home</a>
                    |
                    <a href="admin/index.php">Admin Panel</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div><!--End of Wrapper-->
</body>
</html>
