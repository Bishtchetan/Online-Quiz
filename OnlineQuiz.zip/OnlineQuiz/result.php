<?php
	include 'connection.php';
    $msg ='';
	$foundResult ='';
	if(!isset($_SESSION['email'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
	$user_name = $_SESSION['email'];

	$sql="SELECT * FROM mst_result WHERE user_name='".$user_name."' ORDER BY test_date";
	if($result = mysqli_query($con,$sql)){
		if(mysqli_num_rows($result)>0){
			$foundResult=TRUE;

		}
		else{
			$msg = "No tests have been done yet. ";
		}
	}
	else{
		echo "<script>alert('Error in SQL Query.');</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
     <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        function expand(id){
			document.getElementById(id).children[2].classList.toggle('expand');
		};
		function goReviewPage(id){
			var source = encodeURI(btoa("fromResult"));
			window.location="review.php?tid="+id+"&source="+source;
		}
    </script>

</head>
<body>
<div class="wrapper">
    		<div id="header">
  
    <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
    </nav>
    
  <nav class="navNew">
    <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" >
      <input name="q" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="changePassword.php">Change Password</a></li>
            </ul>
           
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php" >LogOut</a><span class="fa fa-sign-out " style="margin-left: 30px"></span> </li>

             
            </ul>
          </li>
        </ul>        
      </li>
      
     
    </ul>
  </nav>
</div><!--End of header-->
	<div class="shell" style="height:100%;background-image: linear-gradient(#FFEBEE,#000)">
        <div class="shell-body" >
			<center>
			<?php
				if($foundResult){
				while($row=mysqli_fetch_assoc($result)){
						$getTestName = mysqli_query($con,"SELECT * FROM mst_test WHERE id = '".$row['test_id']."'");
						$testName = mysqli_fetch_assoc($getTestName);
						$date = date('d-M-Y',strtotime($row['test_date']));

			?>
						<div class="testBox" id="<?php echo 'test'.$row['test_id']; ?>" style="animation:none;opacity:1;" onclick="expand(id)">
							<div class="resultBoxTitle"><?php echo $testName['test_name']; ?></div>
							<div class="clearFix"></div>
							<div class="resultDetails" id="resultDetails">

								<hr style="border: 1px solid #EAEAEA" />

							<p style="margin-top:3%;"><span class="blueFont">Total Question:</span><span class="yellowFont"><?php echo $row['qus_count']; ?></span> </p>

							<p style="margin:2%;"><span class="blueFont">Date Of Quiz:</span><span class="yellowFont"><?php echo $date; ?></span> </p>

							<p style="margin:2%;"><span class="blueFont">Total Score:</span><span class="yellowFont"><?php echo $row['your_score']; ?>%</span> </p>

							<input type="button" id="<?php echo urlencode(base64_encode($row['test_id'])); ?>" class="quizSubmitButton" onclick="goReviewPage(id)" value="Review" style="margin-bottom:3%;"/>
						</div>
						</div>
				<?php

				}
				}else{
				?>
					<font color="red">Please Play Some Quiz First.</font>
				<?php
				}
				?>
			</center>

		</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div>
</body>
</html>
