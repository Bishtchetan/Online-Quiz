<?php
    include 'connection.php';
    $errorMsg = "";
	if(!isset($_SESSION['email'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
     $tid=base64_decode(urldecode($_GET['tid']));
     
     $sql = "SELECT * FROM mst_test where enable = 1 AND id='$tid'";
     $result1 = mysqli_query($con,$sql);
     $rowusertest = mysqli_fetch_array($result1);
     $testName = $rowusertest['test_name'];
   
     $result2 = mysqli_query($con,"SELECT * FROM mst_subject WHERE enable=1 AND id=".$rowusertest['sub_id']);
     $rowusersubject = mysqli_fetch_array($result2);
     $subjectName = $rowusersubject['sub_name'];
    
    
	if($tid == ''){
		header('location: subject.php');
	}
    $allQuestion=mysqli_query($con,"SELECT * FROM mst_question WHERE enable=1 AND test_id=".$tid);
    if(mysqli_num_rows($allQuestion)>0){
        $foundQuestion=TRUE;
		$qc = mysqli_num_rows($allQuestion);

		$checkReview = "SELECT * FROM mst_result WHERE user_name = '".$_SESSION['email']."' AND test_id = '".$tid."'";
		if($query = mysqli_query($con,$checkReview)){
			if(mysqli_num_rows($query)>0){
				header('location:review.php?tid='.urlencode(base64_encode($tid)).'&source='.urlencode(base64_encode("other")));
			}
		}

	}

    else{
        $foundQuestion=FALSE;
		$errorMsg= "No Question Found";
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
     <link rel="stylesheet" type="text/css" href="css/shell.css" />
     <link rel="stylesheet" type="text/css" href="css/quiz.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--script>
	
    	var tim;
        var min = 9;
        var sec = 60;
        var f = new Date();
        function starttime() {
            showtime();
            document.getElementById("starttime").innerHTML = "<h4>You started your Exam at " + f.getHours() + ":" + f.getMinutes()+"</h4>"; 
        }
        function showtime() {
            if (parseInt(sec) > 0) {
                sec = parseInt(sec) - 1;
                document.getElementById("showtime").innerHTML = "Your Left Time is :"+min+" Minutes :" + sec+" Seconds";
                tim = setTimeout("showtime()", 1000);
            }
            else {
                if (parseInt(sec) == 0) {
                    min = parseInt(min) - 1;
            document.getElementById("showtime").innerHTML = "Your Left Time is :"+min+" Minutes :" + sec+" Seconds";
                    if (parseInt(min) == 0) {
                        clearTimeout(tim);
            alert("Time Up");

                        window.location.href = "login.php";
                    }
                    else {
                        sec = 60;
                        document.getElementById("showtime").innerHTML = "Your Left Time is :" + min + " Minutes :" + sec + " Seconds";
                        tim = setTimeout("showtime()", 1000);
                    }
                }

            }
        }
</script-->
</head>
<body >
<div class="wrapper">
	<div id="header">
  
    <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
    </nav>
    
  <nav class="navNew">
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="" class="aNew" style="padding-right:100px">Menu</a>
        <ul class="mega-dropdown ulNew" style="width:auto">
          <li class="row liNew">
         
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php" >LogOut</a><span class="fa fa-sign-out " style="margin-left: 30px"></span> </li>

             
            </ul>
          </li>
        </ul>        
      </li>
      
     
    </ul>
  </nav>
</div><!--End of header-->
    <div class="shell" style="height:100%;background-image: linear-gradient(#FFEBEE,#000)">
        <div class="shell-body">
			<center>
					
                <p class="headline ">Subject Name:  <?php echo $subjectName;?></p>
				<p class="headline" style="font-size:110%;padding-bottom:1%;color: orange;">Test Name:  <?php echo $testName;?></p>
			</center>
				<div class="quizBox">
					<div class="clearFix"></div>
					<p class="errorMsg"><?php echo $errorMsg; ?></p>
					<?php
						if ($foundQuestion){
					?>
                    
					<form method="POST" action="<?php echo 'quizSubmit.php?tid='.$_GET['tid']; ?>">
					<?php
						$qusCount=0;
						while($qus= mysqli_fetch_assoc($allQuestion)){
						$qusCount++;
					?>
						<p class="question questionDetail"><b><?php echo 'Q.'.$qusCount; ?>&nbsp;&nbsp;</b><?php echo $qus['ques_details']; ?></p>
						<input type="text" hidden="hidden" readonly value="<?php echo $qus['id']; ?>" name="<?php echo 'qid'.$qusCount; ?>">
						 <label class="quizFormAns">	
						 <input type="radio" class="quizRadioBtn" name="<?php echo 'Q'.$qusCount; ?>" value="1" required><label class="text" for="quizRadioBtn"><?php echo $qus['ans1'];?></label></label>
						  <label class="quizFormAns">
						 <input type="radio" class="ansRadio" name="<?php echo 'Q'.$qusCount; ?>" value="2"> <span class="text"><?php echo $qus['ans2'];?></span></label>
						 
					 <label class="quizFormAns">	
						 <input type="radio" class="quizRadioBtn" name="<?php echo 'Q'.$qusCount; ?>" value="3" required><label class="text" for="quizRadioBtn"><?php echo $qus['ans3'];?></label></label>
						  <label class="quizFormAns">
						 <input type="radio" class="ansRadio" name="<?php echo 'Q'.$qusCount; ?>" value="4"> <span class="text"><?php echo $qus['ans4'];?></span></label>
					<?php
						}

					?>
						<center><input type="submit" class="submit" value="Submit"></center>
						<div id="showtime" ></div>
					</form>
					<?php
						}
					?>
				</div>
        </div>
    </div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                    We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div><!--End of Wrapper-->
</body>
</html>
