<?php
//error_reporting(E_ERROR | E_PARSE);
//error_reporting(E_WARNING);
 // error_reporting(0);
	include 'connection.php';
$errorMsg = '';
    if(!isset($_SESSION['email'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
    $tid=base64_decode(urldecode($_GET['tid']));
    
    // $sql1 = "SELECT * FROM mst_test where enable = 1 AND id='$tid'";
    $sql1 = "SELECT * FROM mst_test where id='$tid'";
     $result1 = mysqli_query($con,$sql1);
     $rowusertest = mysqli_fetch_array($result1);
     $testName = $rowusertest['test_name'];

   //$result2 = mysqli_query($con,"SELECT * FROM mst_subject WHERE enable=1 AND id=".$rowusertest['sub_id']);
     $result2 = mysqli_query($con,"SELECT * FROM mst_subject WHERE id=".$rowusertest['sub_id']);
     $rowusersubject = mysqli_fetch_array($result2);
     $subjectName = $rowusersubject['sub_name'];
    
    
	if($tid == ''){
		header('location: quizLandingPage.php');
	}
	if(base64_decode(urldecode($_GET['source']))=="fromResult"){
		$source='fromResult';
	}
	else{
		$source='other';
	}
	$sql = "SELECT * FROM mst_useranswer WHERE test_id='".$tid."' AND user_id='".$_SESSION['id']."'";
 	$allQuestion=mysqli_query($con,$sql);
    if(mysqli_num_rows($allQuestion)>0){
        $foundQuestion=TRUE;
	//	$qc = mysqli_num_rows($allQuestion);
		}
    else{
        $foundQuestion=FALSE;
		$errorMsg= "No Question Found";
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>


    </script>

</head>
<body>
<div class="wrapper">
<div id="header">
  
    <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
    </nav>
    
  <nav class="navNew">
     <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" >
      <input name="q" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="changePassword.php">Change Password</a></li>
            </ul>
           
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php" >LogOut</a><span class="fa fa-sign-out " style="margin-left: 30px"></span> </li>

             
            </ul>
          </li>
        </ul>        
      </li>
      
     
    </ul>
  </nav>
</div><!--End of header-->
    <div class="shell" style="height:100%;background-image: linear-gradient(#FFEBEE,#000)">
        <div class="shell-body" >
			<center>
                <p class="headline ">Subject Name:  <?php echo $subjectName;?></p>
				<p class="headline" style="font-size:110%;padding-bottom:1%;color: orange;">Test Name:  <?php echo $testName;?></p>

				<?php
				if($source=="fromResult"){
				?>
					<a href='result.php'><p class='backlink'><font color=''>&larr;&nbsp;&nbsp;Back To Results</font></p></a>
				<?php
				}
				elseif($source == 'other'){
				?>
					<a href='subject.php'><p class='backlink'><font color=''>&larr;&nbsp;&nbsp;Back To Subjects</font></p></a>
				<?php
				}
				?>
			</center>
				<div class="quizBox">
					<div class="clearFix"></div>
					<p class="errorMsg"><?php echo $errorMsg; ?></p>
					<?php
						if ($foundQuestion){
							while($qus= mysqli_fetch_assoc($allQuestion)){
                                $qusCount++;
					?>
								<p class="question"><b><?php echo 'Q.'.$qusCount; ?>&nbsp;&nbsp;</b><?php echo $qus['ques_details']; ?></p>
								<table class="ansTable">
								<tr>
									<td><b>Ans:</b></td>
									<td><lebel for="quizRadioBtn">1) <?php echo $qus['ans1'];?></lebel></td>
									<td><?php
									echo ($qus['your_ans']==1 && $qus['correct_ans']==1)? '<img src="images/right.png" class="remark"/>':'';

									echo ($qus['your_ans']==1 && $qus['correct_ans']<>1)? '<img src="images/wrong.png" class="remark"/>':'';
									?>
									</td>
								</tr>

								<tr>
									<td></td>
									<td><lebel for="quizRadioBtn">2) <?php echo $qus['ans2'];?></lebel></td>
									<td><?php
									echo ($qus['your_ans']==2 && $qus['correct_ans']==2)? '<img src="images/right.png" class="remark"/>':'';

									echo ($qus['your_ans']==2 && $qus['correct_ans']<>2)? '<img src="images/wrong.png" class="remark"/>':'';

										?></td>
								</tr>
								<tr>
									<td></td>
									<td><lebel for="quizRadioBtn">3) <?php echo $qus['ans3'];?></lebel></td>
									<td><?php echo ($qus['your_ans']==3 && $qus['correct_ans']==3)? '<img src="images/right.png" class="remark"/>':'';

									echo ($qus['your_ans']==3 && $qus['correct_ans']<>3)? '<img src="images/wrong.png" class="remark"/>':''; ?></td>
								</tr>
								<tr>
									<td></td>
									<td><lebel for="quizRadioBtn">4) <?php echo $qus['ans4'];?></lebel></td>
									<td><?php echo ($qus['your_ans']==4 && $qus['correct_ans']==4)? '<img src="images/right.png" class="remark"/>':'';

									echo ($qus['your_ans']==4 && $qus['correct_ans']<>4)? '<img src="images/wrong.png" class="remark"/>':''; ?></td>
								</tr>
								</table>
									<td colspan="4"><p class="corAnswer">Correct Ans: Option <?php echo $qus['correct_ans'];?></p></td>
					<?php
							}
						}
					?>
				</div>
        </div>
    </div>
    <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div><!--End of Wrapper-->
</body>
</html>
