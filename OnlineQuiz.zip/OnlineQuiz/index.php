<?php
    require_once('connection.php');
    if (isset($_SESSION['email'])){
        $login=TRUE;
    }
    else{
        $login=FALSE;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        var redBorder = "border-color:#FE4551;color:#FE4551;box-shadow: 0px 0px 15px 0px rgba(216, 21, 21, 0.70);transition:1s;"
        var whiteBorder = "border-color:#fff;color:#fff;transition:1s;"
        var yellowBorder = "border: 2px solid #FBFF02;"


       
        function checkMailPhone(){
        var email=$("#email").val();
        var phone=$("#phone").val();
        $.ajax({
            type:'post',
                url:'emailPhoneExists.php',
                data:{email: email, phone: phone},
                success:function(msg){
                 if(msg=='mExists'){
                 document.getElementById('email').classList.add('redBorder');
                 document.getElementById('checkEP').innerHTML="<font color='#F6111D'>Email Id already linked with an account</font>";
                 $("#email").val('');
                }
                else if(msg=='pExists'){
                document.getElementById('phone').classList.add('redBorder');
                document.getElementById('checkEP').innerHTML="<font color='#F6111D'>Phone no already linked with an account</font>";
                $("#phone").val('');
                }
                 else if(msg=='allOK'){
               
                 document.getElementById('checkEP').innerHTML="";
                }
                }
         });
        }
        function validateName(name)
        {
            var na= /^[A-Za-z ]+$/;
            return na.test(name);
        }
        function validateEmail(email){
            var re=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }
        function CheckPassword(password) 
        { 
            /* Password should between 6 to 20 char which contains at least one number, one uppercase and one lowercase letter*/
            var pass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
            return pass.test(password);
        }
        function validateCity(city)
        {
            var obj= /^[A-Za-z ]+$/;
            return obj.test(city);
        }
        function isNumber(evt)
        {
             var charCode = (evt.which) ? evt.which : event.keyCode
             if (charCode != 45  && charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

             return true;
        }
       
        function checkNull(id){

            if (document.getElementById(id).value==''){
                document.getElementById(id).classList.add('redBorder');
                return false;
            }
            else{
                document.getElementById(id).classList.remove('redBorder');
                return true;
            }
        }
    
        

        function removeRedborder(id){
            document.getElementById(id).classList.remove('redBorder');
        }


        function checkAllData(){
            var email= document.getElementById('email').value;
            var password= document.getElementById('password').value;
            var name= document.getElementById('name').value;
            var city= document.getElementById('city').value;
            var rtrn = true;

            if (document.getElementById('name').value==''){
                document.getElementById('name').classList.add('redBorder');
                rtrn = false;
            }else if(!validateName(name)){
                document.getElementById('name').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('email').value==''){
                document.getElementById('email').classList.add('redBorder');
                rtrn = false;
            }else if(!validateEmail(email)){
                document.getElementById('email').classList.add('redBorder');
                rtrn = false;

            }

            if (document.getElementById('password').value==''){
                document.getElementById('password').classList.add('redBorder');
                rtrn = false;
            }else if(!CheckPassword(password)){
                document.getElementById('password').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('address').value==''){
                document.getElementById('address').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('city').value==''){
                document.getElementById('city').classList.add('redBorder');
                rtrn = false;
            }else if(!validateCity(city)){
                document.getElementById('city').classList.add('redBorder');
                rtrn = false;
            }

            if (document.getElementById('phone').value=='' || document.getElementById('phone').value.length < 10){
                document.getElementById('phone').classList.add('redBorder');
                rtrn = false;
            }
           return rtrn;
        }



    </script>
</head>
<body>
<div class="wrapper">
    <div class="AboveHeader"></div>
    <div class="header">
        <div class="wrap">
           
            <nav>
                 <a href="index.php"><div class="logo" style="margin-top:0;margin-left:0"></div></a>
             </nav>
            <div class="menu">
                 <nav>
                    <ul class="disableSelect">
                        <li><a href="index.php" class="<?php echo ($login?'hide':'show');?>">HOME</a></li>
                        <li><a href="quizLandingPage.php" class="<?php echo ($login?'show':'hide');?>">HOME</a></li>
                        <li><a href="about.php">ABOUT US</a></li>
                        <!--li><a href="howtoplay.php">HowToPlay</a></li-->
                        <!--li><a href="contact.php">CONTACT US</a></li-->
                        <li><a href="login.php">LOGIN</a></li>
                        <!--li><a href="admin\index.php" class="<?php echo ($login?'hide':'show');?>">ADMIN</a></li-->
                        <li><a href="logout.php" class="<?php echo ($login?'show':'hide');?>">LOGOUT</a></li>

                    </ul>
                </nav>
            </div>
        <div class="clearFix"></div>
        </div>
    </div><!--End of header-->
    <center>
    <div class="mainBody addBG1">
        <h2 class="signUpHeading disableSelect"><span>Register.</span> <font color="#06EA8B"> Participate.</font> Get Certified.</h2>
        <div class="wrap">
            <div class="signUpBox">
                <p class="errorMsg" id="checkEP"></p>
                <form class="signUpForm" id="signUpForm" method="post" action="SQLRegister.php" onsubmit="return checkAllData();" autocomplete="off">
                    <table>
                        <tr>
                            <td><input type="text" id="name" class="transperent" name="name" placeholder="Enter Name" onfocus="removeRedborder(id)" onblur='checkNull(id)' style="width:400px;"/></td>
                        </tr>
                        <tr><td><input type="tel" size=10 maxlength=10 class="transperent" name="phone" placeholder="Enter Contact Number" id="phone" onblur='checkMailPhone(); checkNull(id)' onkeypress='return isNumber(event)' onfocus="removeRedborder(id)" style="width:400px;"/></td></tr>
                        <tr>
                            <td><input type="text" class="transperent" name="email" placeholder="Enter Email" id="email" onblur='checkMailPhone();checkNull(id)' onfocus="removeRedborder(id)" style="width:400px;"/></td>
                        </tr>

                        <tr><td><input type="password" class="transperent" name="password" placeholder="Enter Password" id="password" onblur='checkNull(id)' onfocus="removeRedborder(id)" style="width:400px;"/></td></tr>
                        

                        <tr><td><textarea class="transperent" name="address" placeholder="Enter Address" rows="5" id="address" onblur='checkNull(id)' onfocus="removeRedborder(id)" style="width:400px;"></textarea></td></tr>

                        <tr><td><input type="text" class="transperent" name="city" placeholder="Enter City" id="city" onblur='checkNull(id)' onfocus="removeRedborder(id)" style="width:400px;"/></td></tr>

                        
                        <tr><td></td></tr>
                        <tr><td><input type="submit" class="button transperent" value="Register" style="width:450px;"/></td></tr>
                    </table>
                </form>
            </div>
        </div>

    </div>
    <div style="background-image: linear-gradient(#fff,#fff,#000)" class="mainBody" style="height:400px;">
    <div class="head">
				<h1 class="disableSelect yellowFont" style="font-size:150%"> About Us</h1>
		</div>
        <div class="aboutBody">
            OnlineQuiz is an online based custom quiz application. It provides an user interactive environment and let the user practice quizzes on different topics available in the application.Users have to register themselves to our portal in order to avail quiz services.It contains all the results of the users and users can check their results after logging. Feel free to use and register now to avail the quiz services.
No subscription fee is required, users can enjoy unlimited access to OnlineQuiz, provided they register themselves.  </br>
        <div style="text-align:right"> <a href="about.php" class="yellowFont" >More About Us &rarr;</a></div>
        </div>
    </div>
        </center>
        <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="index.php">Home</a>
                    |
                    <a href="admin/index.php">Admin Panel</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
    

</div><!--End of wrapper-->
</body>
</html>
