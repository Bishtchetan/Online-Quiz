<?php
//error_reporting(E_ERROR | E_PARSE);
//error_reporting(0);
if ( $_SERVER['REQUEST_METHOD']!='POST' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
     
    
        die( header( 'location: error.php' ) );

    }

require_once('connection.php');
$name=$_POST['name'];
$emailClient=$_POST['email'];
$messageForAdmin=$_POST['message'];

$messageForClient = "Thanks a lot <b><i>".ucwords($name)."</i></b> for contacting us. Our team will shortly respond to you.";

$subjectForClient = "Thank You";
$subjectForAdmin = "Query related TYT";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'vendor/autoload.php';

$mail = new PHPMailer(true);

 $mail->SMTPDebug = FALSE;                      
    $mail->isSMTP();                                          
    $mail->Host       = 'smtp.gmail.com';                   
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'TestYourThreshold@gmail.com';                     
    $mail->Password   = 'rncrl1@NF';                               
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
    $mail->Port       = 587;                              

 $mail->setFrom('donotreply.tyt@gmail.com', 'TestYourThreshold');


$mail->addAddress($emailClient, $name);

$mail->isHTML(true);

$mail->Subject = $subjectForClient;
$mail->Body = $messageForClient;

$mailAdmin = new PHPMailer(true);

 $mailAdmin->SMTPDebug = FALSE;                      
    $mailAdmin->isSMTP();                                          
    $mailAdmin->Host       = 'smtp.gmail.com';                   
    $mailAdmin->SMTPAuth   = true;                                   
    $mailAdmin->Username   = 'TestYourThreshold@gmail.com';                     
    $mailAdmin->Password   = 'rncrl1@NF';                               
    $mailAdmin->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
    $mailAdmin->Port       = 587;                              

 $mailAdmin->setFrom('donotreply.tyt@gmail.com', $emailClient);


$mailAdmin->addAddress('TestYourThreshold@gmail.com', 'TYT Admin');

$mailAdmin->isHTML(true);

$mailAdmin->Subject = $subjectForAdmin ;
$mailAdmin->Body = $messageForAdmin;


if(!$mailAdmin->send())
{
   // echo "Mailer Error: " . $mailAdmin->ErrorInfo;
	header('location:contact.php?status='.urlencode(base64_encode("error")));
}
else
{
  if(!$mail->send())
{
   // echo "Mailer Error: " . $mail->ErrorInfo;
	header('location:contact.php?status='.urlencode(base64_encode("error")));
}
else
{
   // echo "Message has been sent successfully";
	header('location:contact.php?status='.urlencode(base64_encode("success")));
}
}





?>
