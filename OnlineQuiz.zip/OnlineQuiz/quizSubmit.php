<?php
    include 'connection.php';
    if(!isset($_SESSION['email'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
    $tid=base64_decode(urldecode($_GET['tid']));
	if($tid == '' || empty($_POST)){
		header('location: quizLandingPage.php');
	}
	$sess_id =  session_id();
	$allQuestion=mysqli_query($con,"SELECT * FROM mst_question WHERE  enable='1' AND test_id=".$tid);
    if(mysqli_num_rows($allQuestion)>0){
		$qc = mysqli_num_rows($allQuestion);
        $foundQuestion=TRUE;
		$count = 1;
	}
	else{
		header('location:quizLandingPage.php');
	}
	$values='';
	$rightAns = 0;
	while($row=mysqli_fetch_assoc($allQuestion))
	{

		if(!empty($_POST['Q'.$count])){
			$yourAns = $_POST['Q'.$count];
		}
		else{
			$yourAns = null;
		}
		if($yourAns == $row['correct_ans']){
			$rightAns += 1;
		}

		//createing multirows values string
		$values=$values."('".$_SESSION['id']."','".$sess_id."','".$tid."','".$row['id']."','".$row['ques_details']."','".$row['ans1']	."','".$row['ans2']."','".$row['ans3']."','".$row['ans4']."','".$row['correct_ans']."','".$yourAns."')";

		$count++;
		//prevent to put the ',' after the last value.
		if($count<=$qc){
			$values = $values . ',';
		}
	}

	$score = ($rightAns/$qc)*100;

	$sql = "INSERT INTO mst_useranswer (user_id,sess_id,test_id,ques_id,ques_details,ans1,ans2,ans3,ans4,correct_ans,your_ans) VAlUES ".$values;
	$date = date('Y/m/d');
	$date=date("Y-m-d",strtotime($date));

	$sqlResult = "INSERT INTO mst_result (user_name,test_id,test_date,your_score,qus_count) VALUES('".$_SESSION['email']."','".$tid."','".$date."','".$score."','".$qc."')";
	$submitSuccess = FALSE;
	if(mysqli_query($con,$sql) && mysqli_query($con,$sqlResult)){
		$submitSuccess = TRUE;
	}
	//echo $sqlResult;
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script>
        function goReview(tid){
			window.location = 'review.php?tid='+tid+'&source='+encodeURI(btoa("other"));

		}
    </script>

</head>
<body>
<div class="wrapper">
   	<div id="header">
  
    <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
    </nav>
    
  <nav class="navNew">
     <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" >
      <input name="q" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="changePassword.php">Change Password</a></li>
            </ul>
           
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php" >LogOut</a><span class="fa fa-sign-out " style="margin-left: 30px"></span> </li>

             
            </ul>
          </li>
        </ul>        
      </li>
      
     
    </ul>
  </nav>
</div><!--End of header-->
    <div class="shell" style="height:100%;background-image: linear-gradient(#FFEBEE,#000)">
        <div class="shell-body" >
			<div class="reviewBox">

			<span style="font-size: 15px; color: #2F4240;font-family: sans-serif;">	Your Score  is <?php echo $score. "%"; ?></span>
				<br/>
				<br/>
				<input type="button" class="quizSubmitButton"onclick="goReview('<?php echo $_GET['tid']; ?>')" value="Review">
			</div>
		</div>
	</div>
	<footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div>
</body>
</html>
