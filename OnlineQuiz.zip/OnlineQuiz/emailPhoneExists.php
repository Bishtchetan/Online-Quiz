<?php

     if ( $_SERVER['REQUEST_METHOD']!='POST' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
     
    
        die( header( 'location: error.php' ) );

    }
    
    require_once('connection.php');
   
    $email=$_POST['email'];
    $phone=$_POST['phone'];

    $checkSql1 = "SELECT * from mst_user WHERE user_email='".$email."'";
    $checkSql2 = "SELECT * from mst_user WHERE user_phone='".$phone."'";

    $hasemail = mysqli_query($con,$checkSql1);
    $hasphone = mysqli_query($con,$checkSql2);
    if(mysqli_num_rows($hasemail)>0){

       echo 'mExists';
       
    }elseif(mysqli_num_rows($hasphone)>0){

        echo 'pExists';
    }else echo "allOK";
   
   
?>
