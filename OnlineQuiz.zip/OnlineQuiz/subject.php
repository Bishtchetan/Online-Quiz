<?php
    include 'connection.php';
    if(!isset($_SESSION['email'])){
        header("location:index.php");
    }
    else{
        $login=TRUE;
    }
    $foundTest= FALSE;
    $foundSubject=FALSE;
    $errorMsg='';
    if(isset($_GET['sid'])){
        $sid=base64_decode(urldecode($_GET['sid']));
        $allTest=mysqli_query($con,"SELECT * FROM mst_test WHERE enable=1 AND sub_id =".$sid);
        if(mysqli_num_rows($allTest)>0){
            $foundTest=TRUE;
        }
        else{
            $errorMsg="No Test Found";

        }
    }
    else{
        $allSubject=mysqli_query($con,"SELECT * FROM mst_subject where enable=1");
        if(mysqli_num_rows($allSubject)>0){
            $foundSubject=TRUE;
        }
        else{
            $errorMsg="No Subject Found";
        }
    }
    $randColor=array('#9C27B0','#00CC00','#663300','#FF6600','#0288D1','#FF00FF');
?>
<!DOCTYPE html>
<html>
<head>
    <title>TestYourThreshold</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
     <link rel="stylesheet" type="text/css" href="css/shell.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script>
        function goTest(id){

            window.location='subject.php?sid='+id;
        }
        function goQuiz(id){
            window.location='quiz.php?tid='+id;
        }
    </script>
    
</head>
<body>
<div class="wrapper">
   	<div id="header">
  
    <nav>
        <a href="quizLandingPage.php"><div class="logo"></div></a>
    </nav>
    
  <nav class="navNew">
    <form class="search" id="searchForm" action="https://www.google.com/search" method="GET" >
      <input name="q" placeholder="Search..." class="inputNew" type="search">
    </form>
    <ul class="ulNew">
     
      <li class="liNew">
        <a href="" class="aNew">Menu</a>
        <ul class="mega-dropdown ulNew">
          <li class="row liNew">
            <ul class="mega-col ulNew">
             
              <li class="liNew"><a href="changePassword.php">Change Password</a></li>
            </ul>
           
            <ul class="mega-col">
              <li class="liNew"><a href="logout.php" >LogOut</a><span class="fa fa-sign-out " style="margin-left: 30px"></span> </li>

             
            </ul>
          </li>
        </ul>        
      </li>
      
     
    </ul>
  </nav>
</div><!--End of header-->
    <div class="shell" style="height:100%;background-image: linear-gradient(#FFEBEE,#000)">
        <div class="shell-body" >
            <center>
            <p class="headline blueHeading">Select Subject And Tests</p>
            <p class="errorMsg"><?php echo $errorMsg; ?></p>
        <?php
            if($foundSubject){
                while ($row=mysqli_fetch_assoc($allSubject)){
                    $id=urlencode(base64_encode($row['id']));
                    $colorIndex=rand(0,5);
        ?>
                                <div class="subjectBox apearFadein" id="<?php echo $id; ?>" onclick="goTest(id)">

                                    <div class="subjctLogo" style="border-color:<?php echo $selectColor;?>;background:<?php echo $randColor[$colorIndex];?>;">
                                        <p class="logoLetter"><?php echo strtoupper(substr($row['sub_name'],0,1)); ?></p>
                                    </div>

                                    <div class="subjectName">
                                        <p><font color="<?php echo $randColor[$colorIndex];?>;"><?php echo ucwords($row['sub_name']); ?></font></p>
                                    </div>

                                    <div class="clearFix"></div>
                                </div>
        <?php
                }//End of whileLoop
            }//End of IF

            elseif($foundTest){
            ?>

            <?php
                $colorIndex=rand(0,5);
                echo "<a href='subject.php'><p class='backlink'><font color='$randColor[$colorIndex]'>&larr;&nbsp;&nbsp;Back To Subjets</p></a>";
                while ($rowTest=mysqli_fetch_assoc($allTest)){
                    $tid=urlencode(base64_encode($rowTest['id']));
                    $allQuestion=mysqli_query($con,"SELECT * FROM mst_question WHERE enable=1 AND test_id=".$rowTest['id']);
                    $qc = mysqli_num_rows($allQuestion);
            ?>
                    <div class="testBox appearFadein" id="<?php echo $tid; ?>" onclick="goQuiz(id)">
                        <div class="testName">
                                        <p><font color="<?php echo $randColor[$colorIndex];?>;">Test Name: <?php echo ucwords($rowTest['test_name']); ?></font></p>
                        </div>
                        <div class="qusCount">
                                        <p><font color="<?php echo $randColor[$colorIndex];?>;">Total Question: <?php echo ucwords($qc); ?> &nbsp;&nbsp;&nbsp;&rarr;</font></p>
                        </div>
                        <div class="clearFix"></div>
                    </div>

        <?php

                }//End of whileLoop
            }//End of IF
        ?>
            </center>
        </div>
    </div>
   <footer class="footer-distributed">
 
            <div class="footer-left">
          <!--img src="../images/logo6.png"-->
                <h3>TestYour<span>Threshold</span></h3>
 
                <p class="footer-links">
                    <a href="quizLandingPage.php">Home</a>
                    |
                    <a href="about.php">About Us</a>
                    |
                    <a href="contact.php">Contact Us</a>
                </p>
 
                <p class="footer-company-name">© 2020 TYT-Online Quiz Pvt. Ltd.</p>
            </div>
 
            <div class="footer-center">
                <div>
                    <i class="fa fa-map-marker"></i>
                      <p><span>MIT WPU, S.No.124, Paud Road, </span>
                       Kothrud, Pune 411038, Maharashtra</p>
                </div>
 
                <div>
                    <i class="fa fa-phone"></i>
                    <p>+919988776655</p>
                </div>
                <div>
                    <i class="fa fa-envelope"></i>
                    <p><a href="mailto:TestYourThreshold@gmail.com">TestYourThreshold@gmail.com</a></p>
                </div>
            </div>
            <div class="footer-right">
                <p class="footer-company-about">
                    <span>About the company</span>
                   We offer Online Quiz and skill building courses across Technology, Design, Management, Science, commerce, Humanities, General Knowledge etc.</p>
                <div class="footer-icons">
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
                    <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </footer>
</div><!--End of Wrapper-->
</body>
</html>
